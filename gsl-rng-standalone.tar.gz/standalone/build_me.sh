# Note: verify gsl module is loaded first...
# 

#gcc -I$GSL_INC main.c mytools.c -lgsl -lgslcblas -L$GSL_LIB 
gcc -I$HOME/local/gsl-2.6/include main.c mytools.c -lgsl -lgslcblas -L$HOME/local/gsl-2.6/lib
